@echo off
setlocal
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0zentao-mcp.ps1" %*
exit /b %ERRORLEVEL%
